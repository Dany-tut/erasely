# Curved shadow

A Figma plugin that puts a soft **curved (arched) shadow** under selected objects —
as if a card, image or sticker were lifted off the page.

## Install (development)
Figma desktop app → Plugins → Development → Import plugin from manifest… → `manifest.json` from this folder.

## How to use
1. Select one or more objects.
2. Run the plugin and adjust the sliders (the preview updates instantly, and the shadow on the
   canvas updates live while something is selected).
3. “Apply shadow” creates or updates the shadow. “Remove shadow” deletes it.

## Settings
- **Width** — arc width, % of the object’s width.
- **Curve** — arc height, %. Negative bends it down (a sag / lifted-corners look).
- **Thickness** — thickness of the shadow stroke, px.
- **Blur** — softness (Layer blur), px.
- **Offset** — distance below the object’s bottom edge, px.
- **Opacity** — shadow opacity, %.
- **Color** — shadow color (black by default).
