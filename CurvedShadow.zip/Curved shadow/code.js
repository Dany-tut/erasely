// Curved shadow — кладёт под выделенные объекты мягкую изогнутую (дуговую) тень.
// Тень — это толстая линия-дуга (quadratic Bézier) с круглыми концами, размытая
// и полупрозрачная, лежащая сразу ПОД объектом в том же родителе.
// Повторное применение обновляет уже созданную тень (помечена pluginData).

let LANG = 'ru';                         // язык сообщений; присылает окно плагина
const tr = (ru, en) => (LANG === 'en' ? en : ru);
const TAG = 'curved-shadow';            // метка узла-тени
const OWNER = 'curved-shadow-owner';    // id объекта, которому принадлежит тень
const DEFAULTS = {
  width: 90,     // ширина тени, % от ширины объекта
  curve: 40,     // изгиб дуги, % (может быть отрицательным — прогиб вниз)
  thickness: 18, // толщина, px
  blur: 24,      // размытие, px
  offsetY: 16,   // отступ вниз от нижней грани объекта, px
  opacity: 35,   // прозрачность, %
  color: '#000000'
};

figma.showUI(__html__, { width: 300, height: 520, themeColors: true });

(async () => {
  let saved = {};
  try { saved = (await figma.clientStorage.getAsync('curved-shadow-settings')) || {}; } catch (e) {}
  figma.ui.postMessage({ type: 'init', settings: Object.assign({}, DEFAULTS, saved) });
  sendSelectionState();
})();

figma.on('selectionchange', sendSelectionState);

function sendSelectionState() {
  const n = figma.currentPage.selection.filter((s) => s.getPluginData(TAG) !== '1').length;
  figma.ui.postMessage({ type: 'selection', count: n });
}

figma.ui.onmessage = async (msg) => {
  if (msg.type === 'lang') {
    LANG = msg.lang === 'en' ? 'en' : 'ru';
  } else if (msg.type === 'apply') {
    try { await figma.clientStorage.setAsync('curved-shadow-settings', msg.settings); } catch (e) {}
    const made = applyToSelection(msg.settings);
    if (made === 0 && !msg.silent) figma.notify(tr('Выделите объект (или несколько), под который положить тень', 'Select one or more objects to put a shadow under'));
    sendSelectionState();
  } else if (msg.type === 'remove') {
    removeFromSelection();
    sendSelectionState();
  } else if (msg.type === 'close') {
    figma.closePlugin();
  }
};

function hexToRgb(hex) {
  const h = String(hex).replace('#', '').trim();
  const s = h.length === 3 ? h.split('').map((c) => c + c).join('') : h;
  const n = parseInt(s, 16);
  if (isNaN(n) || s.length !== 6) return { r: 0, g: 0, b: 0 };
  return { r: ((n >> 16) & 255) / 255, g: ((n >> 8) & 255) / 255, b: (n & 255) / 255 };
}

// Строит/обновляет тень для одного объекта
function makeShadowFor(node, st) {
  if (!node.parent || !('children' in node.parent)) return null;
  const parent = node.parent;
  const index = parent.children.indexOf(node);

  const w = Math.max(1, node.width * (st.width / 100));
  const curve = (node.width * (st.curve / 100)); // вверх при curve>0
  const thickness = Math.max(0.5, st.thickness);

  // убрать прежнюю тень этого объекта, если есть
  const old = parent.children.filter(
    (c) => c.getPluginData(TAG) === '1' && c.getPluginData(OWNER) === node.id
  );
  for (const o of old) o.remove();

  const v = figma.createVector();
  v.setPluginData(TAG, '1');
  v.setPluginData(OWNER, node.id);
  v.name = 'Curved shadow';
  // дуга: от (0,0) к (w,0), контрольная точка посередине приподнята на curve
  v.vectorPaths = [{ windingRule: 'NONE', data: `M 0 0 Q ${w / 2} ${-curve} ${w} 0` }];
  v.strokes = [{ type: 'SOLID', color: hexToRgb(st.color) }];
  v.strokeWeight = thickness;
  v.strokeCap = 'ROUND';
  v.strokeJoin = 'ROUND';
  v.fills = [];
  v.opacity = Math.max(0, Math.min(1, st.opacity / 100));
  try {
    v.effects = [{ type: 'LAYER_BLUR', radius: Math.max(0, st.blur), visible: true }];
  } catch (e) {
    // на случай старого API
    v.effects = [{ type: 'LAYER_BLUR', radius: Math.max(0, st.blur) }];
  }

  // вставить сразу под объект (меньший индекс = ниже по стопке)
  parent.insertChild(index, v);

  // выровнять по центру под объектом
  v.x = node.x + node.width / 2 - v.width / 2;
  v.y = node.y + node.height + st.offsetY;
  return v;
}

function applyToSelection(st) {
  const targets = figma.currentPage.selection.filter((s) => s.getPluginData(TAG) !== '1');
  let made = 0;
  for (const node of targets) {
    if (!('width' in node)) continue;
    const v = makeShadowFor(node, st);
    if (v) made++;
  }
  return made;
}

function removeFromSelection() {
  const ids = figma.currentPage.selection.map((s) => s.id);
  let removed = 0;
  // удалить тени, принадлежащие выделенным объектам, и выделенные тени
  for (const node of figma.currentPage.selection) {
    if (node.getPluginData(TAG) === '1') { node.remove(); removed++; continue; }
    const parent = node.parent;
    if (parent && 'children' in parent) {
      for (const c of parent.children.filter((c) => c.getPluginData(TAG) === '1' && c.getPluginData(OWNER) === node.id)) {
        c.remove(); removed++;
      }
    }
  }
  if (removed === 0) figma.notify(tr('Нет тени для удаления в выделении', 'No shadow to remove in the selection'));
}
