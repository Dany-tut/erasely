// Erasely — стиратель текста (main thread)
// Читает байты выбранного изображения из Figma, отдаёт их в UI,
// получает обратно обработанный PNG с прозрачностью и вставляет его на холст.

let LANG = 'ru';   // язык интерфейса: приходит из UI сообщением {type:'lang'}
const tr = (ru, en) => LANG === 'en' ? en : ru;

const FULL = { w: 1000, h: 700 };
// Таблетка — шапка окна Figma («Erasely ×») и под ней узкая кнопка «Развернуть».
// Шапку рисует сама Figma и клики по ней плагину не приходят, поэтому кнопка своя.
const PILL = { w: 200, h: 36 };
const HEADER = 40;   // высота шапки окна Figma, px

// Позиция окна плагина задаётся в координатах холста, поэтому делим на масштаб
function centerPos(w, h) {
  const vb = figma.viewport.bounds, z = figma.viewport.zoom;
  return { x: vb.x + vb.width / 2 - (w / 2) / z, y: vb.y + vb.height / 2 - ((h + HEADER) / 2) / z };
}

// Открываемся всегда по центру видимой области холста
let startPos;
try { startPos = centerPos(FULL.w, FULL.h); } catch (e) { startPos = undefined; }
figma.showUI(__html__, { width: FULL.w, height: FULL.h, themeColors: true, title: 'Erasely', position: startPos });
// сохранённый выбор языка (переключатель RU/EN в окне)
figma.clientStorage.getAsync('ui-lang').then((l) => { if (l === 'en' || l === 'ru') { LANG = l; figma.ui.postMessage({ type: 'lang-pref', lang: l }); } }).catch(() => {});

// Свернуть окно в таблетку внизу экрана и развернуть обратно по центру
let minimized = false, ignoreId = null;
function minimizeUI(keepId) {
  // результат, который только что выделили, не должен сразу разворачивать окно обратно
  ignoreId = keepId || null;
  try { figma.ui.resize(PILL.w, PILL.h); } catch (e) { figma.ui.resize(PILL.w, 1); }
  try {
    const vb = figma.viewport.bounds, z = figma.viewport.zoom;
    // по центру снизу, выше контекстной панели Figma (Crop / Remove background)
    figma.ui.reposition(vb.x + vb.width / 2 - (PILL.w / 2) / z, vb.y + vb.height - 250 / z);
  } catch (e) { /* старая версия API — остаётся на месте, просто маленькая */ }
  minimized = true;
  figma.notify(tr('Erasely свёрнут. Открыть — кнопка «Развернуть» или выдели другую картинку.', 'Erasely is minimized. Click “Expand” or select another image to open it.'), { timeout: 3500 });
}
function restoreUI() {
  figma.ui.resize(FULL.w, FULL.h);
  try { const c = centerPos(FULL.w, FULL.h); figma.ui.reposition(c.x, c.y); } catch (e) { /* ignore */ }
  minimized = false;
}

// --- Утилиты -----------------------------------------------------------------

// Находит первый image-fill у ноды (Rectangle/Frame/Ellipse и т.п.)
function getImageFill(node) {
  if (!('fills' in node) || node.fills === figma.mixed) return null;
  for (const fill of node.fills) {
    if (fill.type === 'IMAGE' && fill.imageHash) return fill;
  }
  return null;
}

// Возвращает ноду с картинкой из текущего выделения (если есть)
function findSelectedImageNode() {
  for (const node of figma.currentPage.selection) {
    if (getImageFill(node)) return node;
  }
  return null;
}

// Отдаёт в UI картинку из выделения, если она там есть
async function sendSelectionToUI() {
  const node = findSelectedImageNode();
  if (!node) {
    figma.ui.postMessage({ type: 'no-selection' });
    return;
  }
  const fill = getImageFill(node);
  const image = figma.getImageByHash(fill.imageHash);
  if (!image) {
    figma.ui.postMessage({ type: 'no-selection' });
    return;
  }
  try {
    const bytes = await image.getBytesAsync();
    figma.ui.postMessage({
      type: 'image-from-figma',
      bytes,
      nodeId: node.id,
      width: node.width,
      height: node.height
    });
  } catch (e) {
    figma.ui.postMessage({ type: 'error', message: tr('Не удалось прочитать изображение: ', 'Couldn’t read the image: ') + e.message });
  }
}


// --- «Подписи — слоями»: текстовые слои и векторные выноски поверх картинки -------
let fontsCache = null;
async function allFonts() {
  if (!fontsCache) fontsCache = await figma.listAvailableFontsAsync();
  return fontsCache;
}
// Начертание: Regular / Medium / Book… — что есть у семейства
async function pickFont(family) {
  const fonts = (await allFonts()).filter(f => f.fontName.family === family).map(f => f.fontName);
  const pref = ['Regular', 'Medium', 'Book', 'Roman', 'Normal'];
  for (const st of pref) { const f = fonts.find(x => x.style === st); if (f) return f; }
  return fonts[0] || { family: 'Inter', style: 'Regular' };
}
const rgb = (c) => ({ r: c[0] / 255, g: c[1] / 255, b: c[2] / 255 });

async function addLayers(img, L) {
  const s = img.width / L.W;
  const font = await pickFont(L.font || 'Inter');
  await figma.loadFontAsync(font);
  const frame = figma.createFrame();
  frame.name = tr('Подписи', 'Labels'); frame.fills = []; frame.clipsContent = false;
  frame.resize(img.width, img.height);
  // 1) кегль по ширине: ставим слово кеглем 100, меряем и подгоняем под ширину на картинке —
  //    так кегль верный для ЛЮБОГО выбранного шрифта
  const texts = L.labels.map((l) => {
    const t = figma.createText();
    t.fontName = font; t.fontSize = 100; t.textAutoResize = 'WIDTH_AND_HEIGHT';
    t.characters = l.text;
    if (l.lines > 1 && l.lineGap > 0) t.lineHeight = { value: 120, unit: 'PERCENT' };
    frame.appendChild(t);
    const inkW = (l.x1 - l.x0 + 1) * s;
    let fs = t.width > 0 ? 100 * inkW / t.width : l.boxH * 0.85 * s;
    // строку из нескольких строк по ширине самой длинной; не больше, чем позволяет высота
    fs = Math.min(fs, (l.boxH * 1.25) * s);
    return { t, l, fs };
  });
  // 2) подписи примерно одного размера — один кегль (медиана), без разнобоя 13/14/15
  const sorted = texts.map(x => x.fs).sort((a, b) => a - b), med = sorted.length ? sorted[sorted.length >> 1] : 14;
  for (const x of texts) {
    let fs = L.size > 0 ? L.size : (Math.abs(x.fs - med) < 0.18 * med ? med : x.fs);
    x.fs = Math.max(4, Math.round(fs * 2) / 2);
  }
  // 3) порядок номеров: сверху вниз, слева направо
  const order = texts.map((x, i) => i).sort((a, b) => {
    const A = texts[a].l, B = texts[b].l, hA = A.y1 - A.y0;
    return Math.abs(A.y0 - B.y0) < 0.6 * hA ? A.x0 - B.x0 : A.y0 - B.y0;
  });
  order.forEach((idx, k) => {
    const { t, l, fs } = texts[idx];
    t.fontSize = fs;
    if (l.lines > 1 && l.lineGap > 0) t.lineHeight = { value: Math.round(l.lineGap * s * 10) / 10, unit: 'PIXELS' };
    if (L.mode === 'numbers') t.characters = String(k + 1);
    t.fills = [{ type: 'SOLID', color: rgb(l.color) }];
    const align = L.mode === 'numbers' ? 'CENTER' : l.align;
    t.textAlignHorizontal = align;
    t.name = l.text.replace(/\n/g, ' ');
    const x0 = l.x0 * s, x1 = (l.x1 + 1) * s, cx = (x0 + x1) / 2, cy = (l.y0 + l.y1 + 1) / 2 * s;
    t.x = Math.round(align === 'CENTER' ? cx - t.width / 2 : align === 'RIGHT' ? x1 - t.width : x0);
    // по вертикали — центр слоя на центр подписи (чуть ниже: у строчных букв «воздух» сверху)
    t.y = Math.round(cy - t.height / 2 + 0.04 * fs);
  });
  const medSize = med;
  // все выноски одинаковые: одна толщина (медиана) и один вид конца — если у большинства
  // на картинке стрелки, то стрелка у всех
  const lds = (L.leaders || []).filter(ld => ld.pts && ld.pts.length >= 2);
  const ths = lds.map(ld => Math.max(1, (ld.thick || 2) - 1)).sort((a, b) => a - b);
  const oneWeight = Math.max(0.75, Math.round((ths.length ? ths[ths.length >> 1] : 1) * s * 10) / 10);
  const allArrows = lds.length && lds.filter(ld => ld.arrow).length >= 0.6 * lds.length;
  for (const ld of lds) {
    if (!ld.pts || ld.pts.length < 2) continue;
    const xs = ld.pts.map(p => p[0] * s), ys = ld.pts.map(p => p[1] * s);
    const mx = Math.min(...xs), my = Math.min(...ys);
    const v = figma.createVector();
    v.name = tr('Выноска', 'Leader line');
    // вершины по порядку от слова к концу; на конце — наконечник, если на картинке была стрелка
    const verts = xs.map((x, i) => {
      const vx = { x: x - mx, y: ys[i] - my, strokeCap: 'ROUND' };
      if ((ld.arrow || allArrows) && i === xs.length - 1) vx.strokeCap = 'ARROW_LINES';   // наконечник-галочка (как на картинках учебников)
      return vx;
    });
    const segs = verts.slice(1).map((_, i) => ({ start: i, end: i + 1 }));
    await v.setVectorNetworkAsync({ vertices: verts, segments: segs, regions: [] });
    v.strokes = [{ type: 'SOLID', color: { r: 0.12, g: 0.12, b: 0.12 } }];
    v.strokeWeight = oneWeight;
    // концы заданы у вершин (ROUND / стрелка) — общий strokeCap не ставим, он затёр бы стрелку
    frame.appendChild(v);
    v.x = mx; v.y = my;
  }
  // номера: рядом — ключ ответов
  if (L.mode === 'numbers' && order.length) {
    const key = figma.createText();
    key.fontName = font; key.fontSize = Math.max(10, Math.round(medSize));
    key.characters = order.map((idx, k) => (k + 1) + ' — ' + L.labels[idx].text.replace(/\n/g, ' ')).join('\n');
    key.name = tr('Ключ ответов', 'Answer key');
    frame.appendChild(key);
    key.x = img.width + 24; key.y = 0;
  }
  // кладём поверх картинки, в тот же родитель
  const parent = img.parent;
  const auto = parent && 'layoutMode' in parent && parent.layoutMode !== 'NONE';
  parent.insertChild(parent.children.indexOf(img) + 1, frame);
  if (auto) frame.layoutPositioning = 'ABSOLUTE';
  // ровно туда же, где картинка: копируем её матрицу положения целиком (x/y у детей
  // групп, секций и авто-раскладки считаются по-разному — матрица одна и та же)
  frame.relativeTransform = img.relativeTransform;
  if (auto) return frame;
  const g = figma.group([img, frame], parent, parent.children.indexOf(frame) + 1);
  g.name = 'Erasely — ' + img.name;
  return g;
}


// Сколько других картинок лежит ПОД этой на том же месте: их видно сквозь прозрачные
// (стёртые) места, и кажется, что «текст не стёрся»
function copiesUnder(node) {
  const b = node.absoluteBoundingBox; if (!b) return 0;
  let n = 0;
  const seen = new Set();
  const walk = (list) => {
    for (const x of list) {
      if (x.id === node.id || seen.has(x.id)) continue;
      seen.add(x.id);
      if (x.visible !== false && getImageFill(x) && x.absoluteBoundingBox) {
        const c = x.absoluteBoundingBox;
        const ix = Math.max(0, Math.min(b.x + b.width, c.x + c.width) - Math.max(b.x, c.x));
        const iy = Math.max(0, Math.min(b.y + b.height, c.y + c.height) - Math.max(b.y, c.y));
        if (ix * iy > 0.6 * b.width * b.height) n++;
      }
      if ('children' in x && x.type !== 'INSTANCE') walk(x.children);
    }
  };
  walk(figma.currentPage.children);
  return n;
}
function warnCopies(node) {
  const n = copiesUnder(node);
  if (n) figma.notify(LANG === 'en'
    ? 'Heads up: ' + n + (n === 1 ? ' more copy of the image sits' : ' more copies of the image sit') + ' in this spot — you can see through the transparent (erased) areas. Delete the extra copies.'
    : 'Внимание: на этом месте лежит ещё ' + n + ' копи' + (n === 1 ? 'я' : n < 5 ? 'и' : 'й') +
    ' картинки — их видно сквозь прозрачные (стёртые) места. Удали лишние копии.', { timeout: 8000 });
  return n;
}


// Если на месте узла лежит что-то видимое (кроме своих) — правый край помехи, иначе null
function overlapRight(node, skip) {
  const b = node.absoluteBoundingBox; if (!b) return null;
  let right = null;
  const walk = (list) => {
    for (const x of list) {
      if (skip.includes(x.id) || x.visible === false || !x.absoluteBoundingBox) continue;
      const c = x.absoluteBoundingBox;
      const ix = Math.min(b.x + b.width, c.x + c.width) - Math.max(b.x, c.x);
      const iy = Math.min(b.y + b.height, c.y + c.height) - Math.max(b.y, c.y);
      if (ix <= 1 || iy <= 1) continue;
      // контейнер, который целиком больше узла (фрейм страницы, секция), — смотрим внутрь
      if ('children' in x && c.width > b.width * 1.5 && c.height > b.height * 1.5) { walk(x.children); continue; }
      right = Math.max(right === null ? -Infinity : right, c.x + c.width);
    }
  };
  walk(figma.currentPage.children);
  return right;
}

// --- Сообщения из UI ---------------------------------------------------------

figma.ui.onmessage = async (msg) => {
  if (msg.type === 'lang') { LANG = msg.lang === 'en' ? 'en' : 'ru'; if (msg.save) figma.clientStorage.setAsync('ui-lang', LANG).catch(() => {}); return; }
  if (msg.type === 'request-selection') {
    await sendSelectionToUI();
    return;
  }

  // Вставить результат. mode: 'replace' — заменить исходную ноду,
  // 'new' — положить рядом новой нодой.
  if (msg.type === 'place-result') {
    try {
      const image = figma.createImage(new Uint8Array(msg.bytes));
      const w = msg.width;
      const h = msg.height;

      let target = null;
      if (msg.mode === 'replace' && msg.nodeId) {
        target = await figma.getNodeByIdAsync(msg.nodeId);
      }

      const withLayers = msg.layers && msg.layers.labels && msg.layers.labels.length;
      if (target && 'fills' in target && withLayers) {
        // С подписями слоями — бережно: исходную картинку не трогаем, а прячем; стёртая —
        // новым слоем ровно на её месте, и всё это в одной группе с подписями
        const parent = target.parent;
        const auto = parent && 'layoutMode' in parent && parent.layoutMode !== 'NONE';
        const clean = figma.createRectangle();
        clean.resize(target.width, target.height);
        clean.fills = [{ type: 'IMAGE', scaleMode: 'FILL', imageHash: image.hash }];
        clean.name = target.name + tr(' — без подписей', ' — no labels');
        parent.insertChild(parent.children.indexOf(target) + 1, clean);
        if (auto) clean.layoutPositioning = 'ABSOLUTE';
        // результат — СПРАВА от оригинала, а не поверх: оригинал не трогаем, ничего не
        // просвечивает и сразу видно «было → стало»
        const m = target.relativeTransform;
        clean.relativeTransform = [[m[0][0], m[0][1], m[0][2] + target.width + 40], [m[1][0], m[1][1], m[1][2]]];
        // и сдвигаем ещё правее, пока под результатом что-то лежит (другие копии видны
        // сквозь прозрачные места, и кажется, что «подписи не стёрлись»)
        for (let k = 0; k < 40; k++) {
          const hit = overlapRight(clean, [target.id, clean.id]);
          if (hit === null) break;
          const rm = clean.relativeTransform;
          clean.relativeTransform = [[rm[0][0], rm[0][1], rm[0][2] + (hit - clean.absoluteBoundingBox.x) + 40], [rm[1][0], rm[1][1], rm[1][2]]];
        }
        const g = await addLayers(clean, msg.layers);
        figma.currentPage.selection = [g || clean];
        const tb = clean.absoluteBoundingBox;
        if (tb) figma.viewport.center = { x: tb.x + tb.width / 2, y: tb.y + tb.height / 2 };
        minimizeUI((g || clean).id);
        warnCopies(clean);
        figma.ui.postMessage({ type: 'auto-minimized' });
      } else if (target && 'fills' in target) {
        // Меняем заливку существующей ноды на новую картинку
        target.fills = [{
          type: 'IMAGE',
          scaleMode: 'FILL',
          imageHash: image.hash
        }];
        let sel = target;
        figma.currentPage.selection = [sel];
        const tb = target.absoluteBoundingBox;
        if (tb) figma.viewport.center = { x: tb.x + tb.width / 2, y: tb.y + tb.height / 2 };
        minimizeUI(target.id);
        warnCopies(target);
        figma.ui.postMessage({ type: 'auto-minimized' });
      } else {
        // Создаём новую ноду на странице рядом с исходной
        const rect = figma.createRectangle();
        rect.resize(w, h);
        rect.fills = [{
          type: 'IMAGE',
          scaleMode: 'FILL',
          imageHash: image.hash
        }];
        const GAP = 24;
        const src = msg.nodeId ? await figma.getNodeByIdAsync(msg.nodeId) : null;
        const parent = src && src.parent;
        const free = parent && (parent.type === 'PAGE' || parent.type === 'GROUP' || parent.type === 'SECTION' ||
          (('layoutMode' in parent) && parent.layoutMode === 'NONE'));
        if (src && free) {
          // Обычный фрейм/группа/секция: кладём копию туда же, сразу справа от фото
          parent.insertChild(parent.children.indexOf(src) + 1, rect);
          rect.x = src.x + src.width + GAP;
          rect.y = src.y;
          rect.name = 'Erasely — ' + src.name;
        } else if (src && src.absoluteBoundingBox) {
          // Авто-раскладка: внутрь класть нельзя — сдвинется вёрстка. Кладём поверх,
          // на то же место справа от фото (в абсолютных координатах страницы)
          const b = src.absoluteBoundingBox;
          figma.currentPage.appendChild(rect);
          rect.x = b.x + b.width + GAP;
          rect.y = b.y;
          rect.name = 'Erasely — ' + src.name;
        } else {
          figma.currentPage.appendChild(rect);
          rect.x = figma.viewport.center.x - w / 2;
          rect.y = figma.viewport.center.y - h / 2;
          rect.name = tr('Erasely — без текста', 'Erasely — no text');
        }
        let selNew = rect;
        if (msg.layers && msg.layers.labels && msg.layers.labels.length) selNew = await addLayers(rect, msg.layers);
        figma.currentPage.selection = [selNew];
        // вид не двигаем, если копия и так на экране
        const rb = rect.absoluteBoundingBox, vb = figma.viewport.bounds;
        if (rb && (rb.x + rb.width > vb.x + vb.width || rb.y + rb.height > vb.y + vb.height || rb.x < vb.x || rb.y < vb.y)) {
          figma.viewport.center = { x: rb.x + rb.width / 2, y: rb.y + rb.height / 2 };
        }
        minimizeUI(rect.id);
        figma.ui.postMessage({ type: 'auto-minimized' });
      }
    } catch (e) {
      figma.notify(tr('Ошибка вставки: ', 'Placement error: ') + e.message, { error: true });
      figma.ui.postMessage({ type: 'error', message: e.message });
    }
    return;
  }

  if (msg.type === 'get-fonts') {
    try {
      const fams = [...new Set((await allFonts()).map(f => f.fontName.family))].sort((a, b) => a.localeCompare(b));
      const prefs = await figma.clientStorage.getAsync('erasely-prefs');
      figma.ui.postMessage({ type: 'fonts', families: fams, prefs: prefs || null });
    } catch (e) { /* без списка шрифтов — останется Inter */ }
    return;
  }
  if (msg.type === 'save-prefs') { try { await figma.clientStorage.setAsync('erasely-prefs', msg.prefs); } catch (e) { /* ignore */ } return; }
  if (msg.type === 'minimize') { minimizeUI(); return; }
  if (msg.type === 'restore') { restoreUI(); return; }

  if (msg.type === 'close') {
    figma.closePlugin();
    return;
  }
};

// Следим за сменой выделения — удобно переключаться между картинками
figma.on('selectionchange', () => {
  const node = findSelectedImageNode();
  // результат вставки сняли с выделения — дальше и по нему клик разворачивает плагин
  if (minimized && ignoreId && !figma.currentPage.selection.some(n => n.id === ignoreId)) ignoreId = null;
  // свёрнут и выделили картинку — разворачиваемся сразу с ней
  if (minimized && node && node.id !== ignoreId) {
    restoreUI();
    figma.ui.postMessage({ type: 'auto-restored' });
    sendSelectionToUI();
    return;
  }
  figma.ui.postMessage({ type: 'selection-available', available: !!node });
});

// При старте сразу пробуем отдать выделенную картинку
sendSelectionToUI();
